"""
Streamlit frontend for the Personalized Networking Assistant.

Run with:
    streamlit run frontend/app.py

Expects the FastAPI backend to be running (see README.md), by default
at http://localhost:8000. Override with the API_BASE_URL environment
variable if needed.
"""
from __future__ import annotations

import os
from datetime import datetime

import requests
import streamlit as st

API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")

st.set_page_config(page_title="Personalized Networking Assistant", page_icon="🤝", layout="centered")


# ---------------------------------------------------------------------------
# Session state initialization
# ---------------------------------------------------------------------------
def _init_state() -> None:
    defaults = {
        "current_event": "",
        "themes": [],
        "prompts": [],
        "fact_checks": {},  # prompt -> {"facts": [...], "sources": [...]}
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


_init_state()


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------
def analyze_event(event: str) -> list[str]:
    resp = requests.post(f"{API_BASE_URL}/analyze_event", json={"event": event}, timeout=30)
    resp.raise_for_status()
    return resp.json()["themes"]


def generate_topics(themes: list[str], context: str | None) -> list[str]:
    resp = requests.post(
        f"{API_BASE_URL}/generate_topic",
        json={"themes": themes, "context": context},
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["prompts"]


def fact_check(text: str) -> dict:
    resp = requests.get(f"{API_BASE_URL}/fact_check", params={"text": text}, timeout=30)
    resp.raise_for_status()
    return resp.json()


def log_history(event: str, prompt: str, themes: list[str]) -> None:
    resp = requests.post(
        f"{API_BASE_URL}/log_history",
        json={
            "event": event,
            "prompt": prompt,
            "themes": themes,
            "timestamp": datetime.utcnow().isoformat(),
        },
        timeout=30,
    )
    resp.raise_for_status()


def log_feedback(prompt: str, feedback_text: str) -> None:
    resp = requests.post(
        f"{API_BASE_URL}/log_feedback",
        json={
            "prompt": prompt,
            "feedback": feedback_text,
            "timestamp": datetime.utcnow().isoformat(),
        },
        timeout=30,
    )
    resp.raise_for_status()


def fetch_history() -> list[dict]:
    resp = requests.get(f"{API_BASE_URL}/history", timeout=30)
    resp.raise_for_status()
    return resp.json()


def fetch_feedback() -> list[dict]:
    resp = requests.get(f"{API_BASE_URL}/feedback", timeout=30)
    resp.raise_for_status()
    return resp.json()


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------
st.title("🤝 Personalized Networking Assistant")
st.caption("Turn an event description into fact-checked conversation starters.")

tab_generate, tab_history, tab_feedback = st.tabs(["Generate", "Conversation History", "Feedback History"])

with tab_generate:
    event_input = st.text_area(
        "Event description",
        value=st.session_state.current_event,
        placeholder="e.g. A fintech startup mixer focused on AI-driven fraud detection...",
        height=120,
    )

    if st.button("Generate conversation starters", type="primary", disabled=not event_input.strip()):
        st.session_state.current_event = event_input
        with st.spinner("Analyzing event themes..."):
            try:
                st.session_state.themes = analyze_event(event_input)
            except requests.RequestException as exc:
                st.error(f"Could not analyze event: {exc}")
                st.session_state.themes = []

        if st.session_state.themes:
            with st.spinner("Generating prompts..."):
                try:
                    st.session_state.prompts = generate_topics(st.session_state.themes, event_input)
                except requests.RequestException as exc:
                    st.error(f"Could not generate prompts: {exc}")
                    st.session_state.prompts = []
        st.session_state.fact_checks = {}

    if st.session_state.themes:
        st.markdown("**Detected themes:** " + ", ".join(st.session_state.themes))

    if st.session_state.prompts:
        st.subheader("Suggested conversation starters")
        for i, prompt in enumerate(st.session_state.prompts):
            with st.container(border=True):
                st.write(prompt)
                col1, col2, col3 = st.columns([1, 1, 2])

                with col1:
                    if st.button("Fact-check", key=f"factcheck_{i}"):
                        with st.spinner("Checking facts..."):
                            try:
                                st.session_state.fact_checks[prompt] = fact_check(prompt)
                            except requests.RequestException as exc:
                                st.error(f"Fact check failed: {exc}")

                with col2:
                    if st.button("Save to history", key=f"save_{i}"):
                        try:
                            log_history(
                                st.session_state.current_event,
                                prompt,
                                st.session_state.themes,
                            )
                            st.success("Saved!")
                        except requests.RequestException as exc:
                            st.error(f"Could not save: {exc}")

                with col3:
                    rating = st.selectbox(
                        "Rate this",
                        ["👍 Helpful", "👎 Not helpful", "🤔 Neutral"],
                        key=f"rating_{i}",
                        label_visibility="collapsed",
                    )
                    if st.button("Submit feedback", key=f"feedback_{i}"):
                        try:
                            log_feedback(prompt, rating)
                            st.success("Feedback submitted!")
                        except requests.RequestException as exc:
                            st.error(f"Could not submit feedback: {exc}")

                if prompt in st.session_state.fact_checks:
                    fc = st.session_state.fact_checks[prompt]
                    if fc.get("facts"):
                        st.info("**Fact check:**\n\n" + "\n\n".join(fc["facts"]))
                        if fc.get("sources"):
                            st.caption("Source: " + ", ".join(fc["sources"]))
                    else:
                        st.warning("No supporting facts found on Wikipedia.")

with tab_history:
    st.subheader("Conversation History")
    if st.button("Refresh", key="refresh_history"):
        pass  # button click alone triggers a rerun/refetch below
    try:
        records = fetch_history()
        if records:
            st.dataframe(records, use_container_width=True)
        else:
            st.caption("No conversations logged yet.")
    except requests.RequestException as exc:
        st.error(f"Could not load history: {exc}")

with tab_feedback:
    st.subheader("Feedback History")
    if st.button("Refresh", key="refresh_feedback"):
        pass
    try:
        records = fetch_feedback()
        if records:
            st.dataframe(records, use_container_width=True)
        else:
            st.caption("No feedback logged yet.")
    except requests.RequestException as exc:
        st.error(f"Could not load feedback: {exc}")
