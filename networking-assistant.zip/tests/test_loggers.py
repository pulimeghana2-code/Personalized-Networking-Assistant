"""Unit tests for app.services.history_logger and app.services.feedback_logger."""
from __future__ import annotations

import pytest
from sqlmodel import Session

from app.services.feedback_logger import list_feedback, log_feedback
from app.services.history_logger import list_history, log_history


def test_log_history_persists_record(session: Session):
    record = log_history(session, event="AI meetup", prompt="What excites you about AI?", themes=["ai"])
    assert record.id is not None
    assert record.event == "AI meetup"
    assert record.themes_list() == ["ai"]


def test_log_history_empty_event_raises(session: Session):
    with pytest.raises(ValueError):
        log_history(session, event="", prompt="hello")


def test_list_history_orders_newest_first(session: Session):
    log_history(session, event="Event A", prompt="Prompt A")
    log_history(session, event="Event B", prompt="Prompt B")
    records = list_history(session)
    assert [r.event for r in records] == ["Event B", "Event A"]


def test_log_feedback_persists_record(session: Session):
    convo = log_history(session, event="AI meetup", prompt="What excites you about AI?")
    fb = log_feedback(session, prompt="What excites you about AI?", feedback="👍", conversation_id=convo.id)
    assert fb.id is not None
    assert fb.conversation_id == convo.id


def test_log_feedback_empty_feedback_raises(session: Session):
    with pytest.raises(ValueError):
        log_feedback(session, prompt="hello", feedback="")


def test_list_feedback_orders_newest_first(session: Session):
    log_feedback(session, prompt="p1", feedback="f1")
    log_feedback(session, prompt="p2", feedback="f2")
    records = list_feedback(session)
    assert [r.prompt for r in records] == ["p2", "p1"]
