"""Unit tests for app.services.fact_checker."""
from __future__ import annotations

import pytest

from app.services.fact_checker import fact_check


def test_fact_check_returns_facts_and_sources(fake_wikipedia):
    facts, sources = fact_check("artificial intelligence", client=fake_wikipedia)
    assert len(facts) == 3
    assert facts[0].startswith("Artificial intelligence is intelligence")
    assert sources == ["https://en.wikipedia.org/wiki/Artificial_intelligence"]


def test_fact_check_no_results_returns_empty(fake_wikipedia):
    facts, sources = fact_check("nonexistent-topic-xyz", client=fake_wikipedia)
    assert facts == []
    assert sources == []


def test_fact_check_empty_text_raises(fake_wikipedia):
    with pytest.raises(ValueError):
        fact_check("", client=fake_wikipedia)


def test_fact_check_respects_sentence_count(fake_wikipedia):
    facts, _ = fact_check("artificial intelligence", client=fake_wikipedia, sentence_count=1)
    assert len(facts) == 1


def test_fact_check_handles_client_exception():
    class BrokenClient:
        def search(self, query, results=3):
            raise RuntimeError("network down")

    facts, sources = fact_check("anything", client=BrokenClient())
    assert facts == []
    assert sources == []
