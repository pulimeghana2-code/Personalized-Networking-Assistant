"""
Shared pytest fixtures.

Uses an isolated in-memory SQLite database per test (via SQLModel's
StaticPool) and overrides FastAPI's `get_session` dependency so the
TestClient never touches the real `networking_assistant.db` file.
"""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, SQLModel, create_engine
from sqlmodel.pool import StaticPool


@pytest.fixture(name="session")
def session_fixture():
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        yield session


@pytest.fixture(name="client")
def client_fixture(session: Session):
    from app.database import get_session
    from app.main import app

    def get_session_override():
        return session

    app.dependency_overrides[get_session] = get_session_override
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()


class FakeZeroShotClassifier:
    """Deterministic stand-in for the DistilBERT zero-shot pipeline."""

    def __init__(self, labels_and_scores=None):
        self._labels_and_scores = labels_and_scores or [
            ("artificial intelligence", 0.95),
            ("startups and entrepreneurship", 0.87),
            ("finance and investing", 0.40),
            ("sports", 0.05),
        ]

    def __call__(self, sequences, candidate_labels, multi_label=True):
        labels = [l for l, _ in self._labels_and_scores]
        scores = [s for _, s in self._labels_and_scores]
        return {"sequence": sequences, "labels": labels, "scores": scores}


class FakeTextGenerator:
    """Deterministic stand-in for the GPT-2 text-generation pipeline."""

    def __call__(self, prompt, max_new_tokens=40, num_return_sequences=3, do_sample=True, **kwargs):
        canned = [
            "What excites you most about AI in fraud detection?",
            "How did you get started in the fintech space?",
            "What's one trend you think will define this industry next year?",
        ]
        return [
            {"generated_text": prompt + " " + canned[i % len(canned)]}
            for i in range(num_return_sequences)
        ]


class FakeWikipediaClient:
    """Deterministic stand-in for the `wikipedia` module."""

    class _Page:
        url = "https://en.wikipedia.org/wiki/Artificial_intelligence"

    def search(self, query, results=3):
        if "nonexistent-topic-xyz" in query:
            return []
        return ["Artificial intelligence"]

    def summary(self, title, sentences=3, auto_suggest=False):
        return (
            "Artificial intelligence is intelligence demonstrated by machines. "
            "It is used in fraud detection, recommendation systems, and more. "
            "The field has grown rapidly since 2010."
        )

    def page(self, title, auto_suggest=False):
        return self._Page()


@pytest.fixture
def fake_classifier():
    return FakeZeroShotClassifier()


@pytest.fixture
def fake_generator():
    return FakeTextGenerator()


@pytest.fixture
def fake_wikipedia():
    return FakeWikipediaClient()
