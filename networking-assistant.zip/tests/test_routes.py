"""
Integration tests for the FastAPI routes, using `httpx`/`TestClient` and
monkeypatched ML/Wikipedia clients so no model download or network
access is required.
"""
from __future__ import annotations

import pytest

import app.services.event_analyzer as event_analyzer_module
import app.services.fact_checker as fact_checker_module
import app.services.topic_generator as topic_generator_module
from tests.conftest import FakeTextGenerator, FakeWikipediaClient, FakeZeroShotClassifier


@pytest.fixture(autouse=True)
def _patch_ml_backends(monkeypatch):
    """Ensure no route test ever tries to load a real HF/Wikipedia client."""
    monkeypatch.setattr(event_analyzer_module, "_get_classifier", lambda: FakeZeroShotClassifier())
    monkeypatch.setattr(topic_generator_module, "_get_generator", lambda: FakeTextGenerator())
    monkeypatch.setattr(fact_checker_module, "_get_wikipedia_client", lambda: FakeWikipediaClient())


# ---------------------------------------------------------------------------
# /analyze_event
# ---------------------------------------------------------------------------
def test_analyze_event_route_success(client):
    resp = client.post("/analyze_event", json={"event": "A fintech AI mixer"})
    assert resp.status_code == 200
    body = resp.json()
    assert "artificial intelligence" in body["themes"]


def test_analyze_event_route_empty_event_returns_422(client):
    resp = client.post("/analyze_event", json={"event": ""})
    assert resp.status_code == 422  # caught by Pydantic validator


def test_analyze_event_route_missing_field_returns_422(client):
    resp = client.post("/analyze_event", json={})
    assert resp.status_code == 422


# ---------------------------------------------------------------------------
# /generate_topic
# ---------------------------------------------------------------------------
def test_generate_topic_route_success(client):
    resp = client.post("/generate_topic", json={"themes": ["artificial intelligence"], "context": "AI meetup"})
    assert resp.status_code == 200
    body = resp.json()
    assert len(body["prompts"]) > 0


def test_generate_topic_route_empty_themes_returns_422(client):
    resp = client.post("/generate_topic", json={"themes": []})
    assert resp.status_code == 422


def test_generate_topic_route_without_context(client):
    resp = client.post("/generate_topic", json={"themes": ["design"]})
    assert resp.status_code == 200


# ---------------------------------------------------------------------------
# /fact_check
# ---------------------------------------------------------------------------
def test_fact_check_route_success(client):
    resp = client.get("/fact_check", params={"text": "artificial intelligence"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["query"] == "artificial intelligence"
    assert len(body["facts"]) > 0


def test_fact_check_route_no_results(client):
    resp = client.get("/fact_check", params={"text": "nonexistent-topic-xyz"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["facts"] == []


def test_fact_check_route_missing_query_param_returns_422(client):
    resp = client.get("/fact_check")
    assert resp.status_code == 422


# ---------------------------------------------------------------------------
# /log_history and /history
# ---------------------------------------------------------------------------
def test_log_history_route_success(client):
    resp = client.post(
        "/log_history",
        json={"event": "AI meetup", "prompt": "What excites you about AI?", "themes": ["ai"]},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert body["id"] is not None


def test_log_history_route_empty_event_returns_422(client):
    resp = client.post("/log_history", json={"event": "", "prompt": "hi"})
    assert resp.status_code == 422


def test_get_history_route_returns_saved_records(client):
    client.post("/log_history", json={"event": "Event A", "prompt": "Prompt A"})
    resp = client.get("/history")
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 1
    assert body[0]["event"] == "Event A"


# ---------------------------------------------------------------------------
# /log_feedback and /feedback
# ---------------------------------------------------------------------------
def test_log_feedback_route_success(client):
    resp = client.post("/log_feedback", json={"prompt": "What excites you?", "feedback": "👍"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert body["id"] is not None


def test_log_feedback_route_empty_feedback_returns_422(client):
    resp = client.post("/log_feedback", json={"prompt": "hi", "feedback": ""})
    assert resp.status_code == 422


def test_get_feedback_route_returns_saved_records(client):
    client.post("/log_feedback", json={"prompt": "p1", "feedback": "f1"})
    resp = client.get("/feedback")
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 1
    assert body[0]["prompt"] == "p1"


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------
def test_health_check(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
