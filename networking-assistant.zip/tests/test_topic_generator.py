"""Unit tests for app.services.topic_generator."""
from __future__ import annotations

import pytest

from app.services.topic_generator import _clean_generated_text, generate_topics


def test_generate_topics_returns_prompts(fake_generator):
    prompts = generate_topics(
        ["artificial intelligence", "startups"],
        context="fintech mixer",
        generator=fake_generator,
        max_prompts=2,
    )
    assert len(prompts) == 2
    assert all(isinstance(p, str) and p for p in prompts)


def test_generate_topics_deduplicates(fake_generator):
    def repeating_generator(prompt, max_new_tokens=40, num_return_sequences=3, do_sample=True, **kw):
        return [{"generated_text": prompt + " Same question?"} for _ in range(num_return_sequences)]

    prompts = generate_topics(["ai"], generator=repeating_generator, max_prompts=3)
    assert len(prompts) == 1
    assert prompts[0] == "Same question?"


def test_generate_topics_empty_themes_raises(fake_generator):
    with pytest.raises(ValueError):
        generate_topics([], generator=fake_generator)


def test_generate_topics_without_context(fake_generator):
    prompts = generate_topics(["design"], context=None, generator=fake_generator, max_prompts=1)
    assert len(prompts) == 1


def test_clean_generated_text_strips_seed_and_trims():
    seed = "Some seed text:\n1."
    raw = seed + " What is your favorite tool?\n2. Another one here"
    cleaned = _clean_generated_text(raw, seed)
    assert cleaned == "What is your favorite tool?"


def test_clean_generated_text_trims_incomplete_sentence():
    seed = "seed"
    raw = "seed A complete sentence. And an incomplete frag"
    cleaned = _clean_generated_text(raw, seed)
    assert cleaned == "A complete sentence."
