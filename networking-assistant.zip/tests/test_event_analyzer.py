"""Unit tests for app.services.event_analyzer."""
from __future__ import annotations

import pytest

from app.services.event_analyzer import analyze_event
from tests.conftest import FakeZeroShotClassifier


def test_analyze_event_returns_top_themes(fake_classifier):
    themes = analyze_event(
        "A fintech mixer about AI-driven fraud detection for startups",
        classifier=fake_classifier,
        max_themes=2,
    )
    assert themes == ["artificial intelligence", "startups and entrepreneurship"]


def test_analyze_event_respects_max_themes_default(fake_classifier):
    themes = analyze_event("An event about AI and finance", classifier=fake_classifier)
    # default max_themes is 5 but the fake classifier only returns 4 labels
    assert len(themes) == 4


def test_analyze_event_empty_string_raises(fake_classifier):
    with pytest.raises(ValueError):
        analyze_event("", classifier=fake_classifier)


def test_analyze_event_whitespace_only_raises(fake_classifier):
    with pytest.raises(ValueError):
        analyze_event("   ", classifier=fake_classifier)


def test_analyze_event_uses_custom_candidate_labels():
    clf = FakeZeroShotClassifier(
        labels_and_scores=[("cooking", 0.9), ("travel", 0.5)]
    )
    themes = analyze_event(
        "A dinner party for foodies",
        classifier=clf,
        candidate_labels=["cooking", "travel"],
        max_themes=1,
    )
    assert themes == ["cooking"]
