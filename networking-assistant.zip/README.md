# Personalized Networking Assistant

An AI-powered app that turns an event description into personalized,
fact-checked conversation starters.

- **DistilBERT** (zero-shot classification) extracts key themes from your event description.
- **GPT-2** generates context-aware ice-breaker prompts for those themes.
- **Wikipedia API** fact-checks/enriches the suggested prompts.
- Conversation history and user feedback are logged to a SQLite database.

## Architecture

Modular microservice-style design, all served from one FastAPI app via routers:

```
app/
  main.py                 FastAPI app, router registration, startup DB init
  config.py                Centralized settings (model names, DB URL, etc.)
  database.py               SQLModel engine/session
  models.py                  SQLModel tables + Pydantic request/response schemas
  services/
    event_analyzer.py        DistilBERT theme extraction
    topic_generator.py       GPT-2 prompt generation
    fact_checker.py          Wikipedia-based fact checking
    history_logger.py        Conversation persistence
    feedback_logger.py       Feedback persistence
  routers/
    analyze.py    -> POST /analyze_event
    generate.py   -> POST /generate_topic
    factcheck.py  -> GET  /fact_check
    history.py    -> POST /log_history, GET /history
    feedback.py   -> POST /log_feedback, GET /feedback
frontend/
  app.py                      Streamlit UI
tests/
  test_event_analyzer.py
  test_topic_generator.py
  test_fact_checker.py
  test_loggers.py
  test_routes.py
  conftest.py                 Shared fixtures + fake ML/Wikipedia clients
```

Layering: **routes → service functions → database models.** Routes contain no
business logic; they validate input, call a service, and map errors to HTTP
status codes.

## API Reference

| Method | Path            | Body / Query                                   | Response                              |
|--------|-----------------|-------------------------------------------------|----------------------------------------|
| POST   | `/analyze_event`| `{"event": "..."}`                               | `{"themes": ["..."]}`                  |
| POST   | `/generate_topic`| `{"themes": [...], "context": "..." (optional)}`| `{"prompts": ["..."]}`                 |
| GET    | `/fact_check`   | `?text=...`                                      | `{"query", "facts": [...], "sources": [...]}` |
| POST   | `/log_history`  | `{"event", "prompt", "themes", "timestamp"}`     | `{"success": true, "id": 1}`           |
| GET    | `/history`      | –                                                 | list of conversation records            |
| POST   | `/log_feedback` | `{"prompt", "feedback", "conversation_id", "timestamp"}` | `{"success": true, "id": 1}`  |
| GET    | `/feedback`     | –                                                 | list of feedback records                |
| GET    | `/health`       | –                                                 | `{"status": "ok"}`                      |

Interactive docs are available at `http://localhost:8000/docs` once the server is running.

## Setup

```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

> **Note:** the first request to `/analyze_event` or `/generate_topic` will
> download the DistilBERT and GPT-2 model weights from Hugging Face
> (a few hundred MB total). This requires internet access and may take a
> minute the first time; the models are cached locally afterward.

## Running the backend

```bash
uvicorn app.main:app --reload
```

The API will be available at `http://localhost:8000` (docs at `/docs`).
A SQLite database file (`networking_assistant.db`) is created automatically
on startup.

## Running the frontend

In a second terminal (with the backend already running):

```bash
streamlit run frontend/app.py
```

By default the frontend calls the API at `http://localhost:8000`. Override
with the `API_BASE_URL` environment variable if your backend runs elsewhere:

```bash
API_BASE_URL=http://localhost:8000 streamlit run frontend/app.py
```

## Running tests

```bash
pytest
```

All ML models (DistilBERT, GPT-2) and the Wikipedia client are mocked in
tests (see `tests/conftest.py`), so the test suite runs fully offline and
does not require model downloads. Tests cover:

- Each service function directly (typical + edge cases: empty input,
  no results found, upstream client exceptions).
- Every FastAPI route via `TestClient`, checking status codes and response
  shapes for both success and validation-error paths.

## Configuration

All configuration is read from environment variables (see `app/config.py`
for defaults), including:

- `DATABASE_URL` – SQLAlchemy/SQLModel database URL (default: local SQLite file).
- `THEME_MODEL_NAME` – Hugging Face model id for theme extraction.
- `GENERATION_MODEL_NAME` – Hugging Face model id for prompt generation.
- `MAX_THEMES`, `MAX_PROMPTS`, `GENERATION_MAX_NEW_TOKENS`, `FACT_CHECK_SENTENCE_COUNT`.
- `API_BASE_URL` – used by the Streamlit frontend to reach the backend.

## Docker

A `Dockerfile` is provided for the backend:

```bash
docker build -t networking-assistant .
docker run -p 8000:8000 networking-assistant
```

Run the Streamlit frontend separately (locally or in its own container)
pointed at the backend's URL via `API_BASE_URL`.
