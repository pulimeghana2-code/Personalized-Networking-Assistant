"""
Centralized configuration for the Networking Assistant application.

All environment-driven settings live here so that services and routers
never read `os.environ` directly. This keeps configuration easy to
override in tests (via monkeypatching `settings`) and in deployment
(via environment variables).
"""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    # --- Database -----------------------------------------------------
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./networking_assistant.db")

    # --- Model names ----------------------------------------------------
    # Zero-shot classification model used by the Event Analyzer to score
    # candidate themes against the raw event description.
    theme_model_name: str = os.getenv(
        "THEME_MODEL_NAME", "typeform/distilbert-base-uncased-mnli"
    )
    # Causal language model used by the Topic Generator to draft
    # ice-breaker conversation prompts.
    generation_model_name: str = os.getenv("GENERATION_MODEL_NAME", "gpt2")

    # --- Behaviour knobs --------------------------------------------------
    max_themes: int = int(os.getenv("MAX_THEMES", "5"))
    max_prompts: int = int(os.getenv("MAX_PROMPTS", "3"))
    generation_max_new_tokens: int = int(os.getenv("GENERATION_MAX_NEW_TOKENS", "40"))
    fact_check_sentence_count: int = int(os.getenv("FACT_CHECK_SENTENCE_COUNT", "3"))

    # --- API -------------------------------------------------------------
    api_base_url: str = os.getenv("API_BASE_URL", "http://localhost:8000")

    # Candidate theme labels used for zero-shot classification. Kept here
    # so they can be tuned without touching service logic.
    candidate_themes: tuple[str, ...] = (
        "technology",
        "startups and entrepreneurship",
        "artificial intelligence",
        "marketing",
        "finance and investing",
        "healthcare",
        "education",
        "career development",
        "design",
        "sustainability",
        "arts and culture",
        "sports",
        "science and research",
        "social impact",
        "leadership",
    )


settings = Settings()
