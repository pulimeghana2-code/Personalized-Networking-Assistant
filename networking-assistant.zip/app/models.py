"""
Persistence models (SQLModel) and API schemas (Pydantic) shared across
the application.

SQLModel classes double as both the ORM table definition and, where
convenient, the API schema. Pure request/response schemas that don't
need a table are defined with `table=False` (the SQLModel default).
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import List, Optional

from pydantic import field_validator
from sqlmodel import Field, SQLModel


# ---------------------------------------------------------------------------
# Database tables
# ---------------------------------------------------------------------------
class Conversation(SQLModel, table=True):
    """A logged record of an event + the prompts generated/chosen for it."""

    id: Optional[int] = Field(default=None, primary_key=True)
    event: str
    prompt: str
    themes: str = Field(default="[]")  # JSON-encoded list[str]
    timestamp: datetime = Field(default_factory=datetime.utcnow)

    def themes_list(self) -> List[str]:
        try:
            return json.loads(self.themes)
        except (TypeError, ValueError):
            return []


class Feedback(SQLModel, table=True):
    """User feedback on a specific generated prompt."""

    id: Optional[int] = Field(default=None, primary_key=True)
    conversation_id: Optional[int] = Field(default=None, foreign_key="conversation.id")
    prompt: str
    feedback: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------
class EventAnalyzeRequest(SQLModel):
    event: str

    @field_validator("event")
    @classmethod
    def event_not_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("event must be a non-empty string")
        return v.strip()


class EventAnalyzeResponse(SQLModel):
    themes: List[str]


class TopicGenerateRequest(SQLModel):
    themes: List[str]
    context: Optional[str] = None

    @field_validator("themes")
    @classmethod
    def themes_not_empty(cls, v: List[str]) -> List[str]:
        if not v:
            raise ValueError("themes must contain at least one item")
        return v


class TopicGenerateResponse(SQLModel):
    prompts: List[str]


class FactCheckResponse(SQLModel):
    query: str
    facts: List[str]
    sources: List[str]


class HistoryCreateRequest(SQLModel):
    event: str
    prompt: str
    themes: List[str] = []
    timestamp: Optional[datetime] = None

    @field_validator("event", "prompt")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("field must be a non-empty string")
        return v.strip()


class HistoryCreateResponse(SQLModel):
    success: bool
    id: Optional[int] = None


class FeedbackCreateRequest(SQLModel):
    prompt: str
    feedback: str
    conversation_id: Optional[int] = None
    timestamp: Optional[datetime] = None

    @field_validator("prompt", "feedback")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("field must be a non-empty string")
        return v.strip()


class FeedbackCreateResponse(SQLModel):
    success: bool
    id: Optional[int] = None
