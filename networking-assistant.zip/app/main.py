"""
FastAPI application entrypoint for the Personalized Networking Assistant.

Run with:
    uvicorn app.main:app --reload
"""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import init_db
from app.routers import analyze, factcheck, feedback, generate, history

app = FastAPI(
    title="Personalized Networking Assistant",
    description=(
        "Generates personalized, fact-checked conversation starters for "
        "networking events."
    ),
    version="1.0.0",
)

# Allow the Streamlit frontend (typically on a different port) to call this API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(analyze.router)
app.include_router(generate.router)
app.include_router(factcheck.router)
app.include_router(history.router)
app.include_router(feedback.router)


@app.on_event("startup")
def on_startup() -> None:
    init_db()


@app.get("/health", tags=["Health"])
def health_check() -> dict:
    return {"status": "ok"}
