"""
Topic Generator service.

Given a list of themes (and optional extra context), produces a small
set of conversational ice-breaker prompts using a GPT-2 text-generation
pipeline.
"""
from __future__ import annotations

import re
from functools import lru_cache
from typing import List, Optional, Protocol

from app.config import settings


class TextGenerator(Protocol):
    """Structural type for the piece of the HF pipeline API we rely on."""

    def __call__(
        self,
        prompt: str,
        max_new_tokens: int = ...,
        num_return_sequences: int = ...,
        do_sample: bool = ...,
        **kwargs,
    ) -> List[dict]:
        ...


@lru_cache(maxsize=1)
def _get_generator() -> TextGenerator:
    """Lazily construct and cache the GPT-2 text-generation pipeline."""
    from transformers import pipeline

    return pipeline("text-generation", model=settings.generation_model_name)


def _build_seed_prompt(themes: List[str], context: Optional[str]) -> str:
    theme_str = ", ".join(themes)
    seed = f"Here are some great conversation starters about {theme_str} for a networking event"
    if context:
        seed += f" ({context.strip()})"
    seed += ":\n1."
    return seed


def _clean_generated_text(raw: str, seed: str) -> str:
    """Strip the seed prompt and trim to a single reasonable sentence/line."""
    text = raw[len(seed):] if raw.startswith(seed) else raw
    # Keep text up to the first newline or numbered list marker, since the
    # model tends to keep generating additional list items.
    text = re.split(r"\n\s*\d+\.|\n\n", text)[0]
    text = text.strip(" -\u2022\n\t")
    if text and text[-1] not in ".?!":
        # Trim to the last full sentence if generation was cut off mid-word.
        last_punct = max(text.rfind("."), text.rfind("?"), text.rfind("!"))
        if last_punct > 0:
            text = text[: last_punct + 1]
    return text.strip()


def generate_topics(
    themes: List[str],
    context: Optional[str] = None,
    *,
    max_prompts: Optional[int] = None,
    generator: Optional[TextGenerator] = None,
) -> List[str]:
    """
    Generate ice-breaker conversation prompts for the given themes.

    Args:
        themes: List of theme keywords (e.g. from the Event Analyzer).
        context: Optional additional event context to steer generation.
        max_prompts: Maximum number of prompts to return. Defaults to
            `settings.max_prompts`.
        generator: Optional injected generator callable (used by tests).

    Returns:
        A list of generated prompt strings, deduplicated and non-empty.

    Raises:
        ValueError: If `themes` is empty.
    """
    if not themes:
        raise ValueError("themes must contain at least one item")

    max_prompts = max_prompts or settings.max_prompts
    gen = generator or _get_generator()
    seed = _build_seed_prompt(themes, context)

    outputs = gen(
        seed,
        max_new_tokens=settings.generation_max_new_tokens,
        num_return_sequences=max_prompts,
        do_sample=True,
    )

    prompts: List[str] = []
    seen = set()
    for item in outputs:
        generated = item.get("generated_text", "") if isinstance(item, dict) else str(item)
        cleaned = _clean_generated_text(generated, seed)
        if cleaned and cleaned.lower() not in seen:
            seen.add(cleaned.lower())
            prompts.append(cleaned)

    return prompts[:max_prompts]
