"""
History Logger service.

Persists conversation records (event description, chosen prompt,
associated themes, timestamp) to the database.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import List, Optional

from sqlmodel import Session, select

from app.models import Conversation


def log_history(
    session: Session,
    *,
    event: str,
    prompt: str,
    themes: Optional[List[str]] = None,
    timestamp: Optional[datetime] = None,
) -> Conversation:
    """
    Persist a new conversation record.

    Args:
        session: Active database session.
        event: The event description.
        prompt: The chosen/generated prompt text.
        themes: Optional list of themes associated with the event.
        timestamp: Optional explicit timestamp; defaults to now (UTC).

    Returns:
        The persisted `Conversation` row (with its assigned `id`).

    Raises:
        ValueError: If `event` or `prompt` is empty.
    """
    if not event or not event.strip():
        raise ValueError("event must be a non-empty string")
    if not prompt or not prompt.strip():
        raise ValueError("prompt must be a non-empty string")

    conversation = Conversation(
        event=event.strip(),
        prompt=prompt.strip(),
        themes=json.dumps(themes or []),
        timestamp=timestamp or datetime.utcnow(),
    )
    session.add(conversation)
    session.commit()
    session.refresh(conversation)
    return conversation


def list_history(session: Session, *, limit: int = 100) -> List[Conversation]:
    """Return the most recent conversation records, newest first."""
    statement = select(Conversation).order_by(Conversation.timestamp.desc()).limit(limit)
    return list(session.exec(statement))
