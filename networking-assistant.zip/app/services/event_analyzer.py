"""
Event Analyzer service.

Extracts key themes from a free-text event description using a
DistilBERT zero-shot classification model. The model scores the
description against a fixed list of candidate theme labels
(`settings.candidate_themes`) and returns the highest-scoring ones.

The Hugging Face pipeline is loaded lazily and cached at module scope
so it is only downloaded/initialized once per process, and so that
unit tests can monkeypatch `_get_classifier` to avoid any network or
GPU dependency.
"""
from __future__ import annotations

from functools import lru_cache
from typing import List, Optional, Protocol

from app.config import settings


class ZeroShotClassifier(Protocol):
    """Structural type for the piece of the HF pipeline API we rely on."""

    def __call__(self, sequences: str, candidate_labels: List[str], multi_label: bool = ...) -> dict:
        ...


@lru_cache(maxsize=1)
def _get_classifier() -> ZeroShotClassifier:
    """Lazily construct and cache the zero-shot classification pipeline."""
    from transformers import pipeline

    return pipeline("zero-shot-classification", model=settings.theme_model_name)


def analyze_event(
    event: str,
    *,
    max_themes: Optional[int] = None,
    classifier: Optional[ZeroShotClassifier] = None,
    candidate_labels: Optional[List[str]] = None,
) -> List[str]:
    """
    Extract the top themes for an event description.

    Args:
        event: Raw event description text.
        max_themes: Maximum number of themes to return. Defaults to
            `settings.max_themes`.
        classifier: Optional injected classifier callable (used by tests
            to avoid loading the real model).
        candidate_labels: Optional override of the candidate theme list.

    Returns:
        A list of theme labels ordered from most to least relevant.

    Raises:
        ValueError: If `event` is empty or whitespace-only.
    """
    if not event or not event.strip():
        raise ValueError("event must be a non-empty string")

    max_themes = max_themes or settings.max_themes
    labels = list(candidate_labels or settings.candidate_themes)
    clf = classifier or _get_classifier()

    result = clf(event, candidate_labels=labels, multi_label=True)

    # HF zero-shot pipelines return {"labels": [...], "scores": [...]}
    # already sorted by descending score.
    ranked_labels = result.get("labels", [])
    return ranked_labels[:max_themes]
