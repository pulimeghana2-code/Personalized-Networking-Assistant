"""
Fact Checker service.

Verifies / enriches a piece of text (typically a generated prompt or a
keyword extracted from one) by looking it up on Wikipedia and returning
a handful of summary sentences plus source URLs.
"""
from __future__ import annotations

from typing import List, Optional, Protocol, Tuple

from app.config import settings


class WikipediaClient(Protocol):
    """Structural type for the subset of the `wikipedia` module we use."""

    def search(self, query: str, results: int = ...) -> List[str]:
        ...

    def summary(self, title: str, sentences: int = ..., auto_suggest: bool = ...) -> str:
        ...

    def page(self, title: str, auto_suggest: bool = ...):
        ...


def _get_wikipedia_client() -> WikipediaClient:
    import wikipedia

    return wikipedia


def _split_sentences(text: str) -> List[str]:
    # Lightweight sentence split; avoids pulling in a full NLP dependency
    # just for this. Good enough for Wikipedia's fairly clean prose.
    raw_sentences = [s.strip() for s in text.replace("\n", " ").split(". ")]
    sentences = []
    for s in raw_sentences:
        if not s:
            continue
        sentences.append(s if s.endswith((".", "!", "?")) else s + ".")
    return sentences


def fact_check(
    text: str,
    *,
    sentence_count: Optional[int] = None,
    client: Optional[WikipediaClient] = None,
) -> Tuple[List[str], List[str]]:
    """
    Look up `text` on Wikipedia and return supporting facts + sources.

    Args:
        text: Query text to verify/enrich (e.g. a prompt or keyword).
        sentence_count: Max number of summary sentences to return.
        client: Optional injected Wikipedia client (used by tests).

    Returns:
        A `(facts, sources)` tuple. `facts` is empty if no matching page
        is found; `sources` contains page URL(s) when available.

    Raises:
        ValueError: If `text` is empty or whitespace-only.
    """
    if not text or not text.strip():
        raise ValueError("text must be a non-empty string")

    sentence_count = sentence_count or settings.fact_check_sentence_count
    wiki = client or _get_wikipedia_client()

    try:
        search_results = wiki.search(text, results=3)
    except Exception:
        return [], []

    if not search_results:
        return [], []

    title = search_results[0]

    try:
        summary_text = wiki.summary(title, sentences=sentence_count, auto_suggest=False)
    except Exception:
        return [], []

    facts = _split_sentences(summary_text)[:sentence_count]

    sources: List[str] = []
    try:
        page = wiki.page(title, auto_suggest=False)
        url = getattr(page, "url", None)
        if url:
            sources.append(url)
    except Exception:
        pass

    return facts, sources
