"""
Feedback Logger service.

Persists user feedback (rating/comment) on a specific generated prompt,
optionally linked back to a Conversation record.
"""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from sqlmodel import Session, select

from app.models import Feedback


def log_feedback(
    session: Session,
    *,
    prompt: str,
    feedback: str,
    conversation_id: Optional[int] = None,
    timestamp: Optional[datetime] = None,
) -> Feedback:
    """
    Persist a new feedback record.

    Args:
        session: Active database session.
        prompt: The prompt text the feedback refers to.
        feedback: The feedback content (rating, comment, etc).
        conversation_id: Optional foreign key to a `Conversation` row.
        timestamp: Optional explicit timestamp; defaults to now (UTC).

    Returns:
        The persisted `Feedback` row (with its assigned `id`).

    Raises:
        ValueError: If `prompt` or `feedback` is empty.
    """
    if not prompt or not prompt.strip():
        raise ValueError("prompt must be a non-empty string")
    if not feedback or not feedback.strip():
        raise ValueError("feedback must be a non-empty string")

    record = Feedback(
        prompt=prompt.strip(),
        feedback=feedback.strip(),
        conversation_id=conversation_id,
        timestamp=timestamp or datetime.utcnow(),
    )
    session.add(record)
    session.commit()
    session.refresh(record)
    return record


def list_feedback(session: Session, *, limit: int = 100) -> List[Feedback]:
    """Return the most recent feedback records, newest first."""
    statement = select(Feedback).order_by(Feedback.timestamp.desc()).limit(limit)
    return list(session.exec(statement))
