"""Router: POST /log_history and GET /history"""
from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from app.database import get_session
from app.models import Conversation, HistoryCreateRequest, HistoryCreateResponse
from app.services.history_logger import list_history, log_history

router = APIRouter(tags=["History Logger"])


@router.post("/log_history", response_model=HistoryCreateResponse)
def log_history_route(
    payload: HistoryCreateRequest, session: Session = Depends(get_session)
) -> HistoryCreateResponse:
    try:
        record = log_history(
            session,
            event=payload.event,
            prompt=payload.prompt,
            themes=payload.themes,
            timestamp=payload.timestamp,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return HistoryCreateResponse(success=True, id=record.id)


@router.get("/history", response_model=List[Conversation])
def get_history_route(session: Session = Depends(get_session)) -> List[Conversation]:
    return list_history(session)
