"""Router: GET /fact_check"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from app.models import FactCheckResponse
from app.services.fact_checker import fact_check

router = APIRouter(tags=["Fact Checker"])


@router.get("/fact_check", response_model=FactCheckResponse)
def fact_check_route(text: str = Query(..., min_length=1)) -> FactCheckResponse:
    try:
        facts, sources = fact_check(text)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # pragma: no cover - defensive catch-all
        raise HTTPException(status_code=502, detail=f"Fact check failed: {exc}") from exc
    return FactCheckResponse(query=text, facts=facts, sources=sources)
