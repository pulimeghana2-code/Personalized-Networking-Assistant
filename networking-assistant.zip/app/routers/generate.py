"""Router: POST /generate_topic"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.models import TopicGenerateRequest, TopicGenerateResponse
from app.services.topic_generator import generate_topics

router = APIRouter(tags=["Topic Generator"])


@router.post("/generate_topic", response_model=TopicGenerateResponse)
def generate_topic_route(payload: TopicGenerateRequest) -> TopicGenerateResponse:
    try:
        prompts = generate_topics(payload.themes, payload.context)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # pragma: no cover - defensive catch-all
        raise HTTPException(status_code=502, detail=f"Prompt generation failed: {exc}") from exc
    return TopicGenerateResponse(prompts=prompts)
