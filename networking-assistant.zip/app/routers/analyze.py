"""Router: POST /analyze_event"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.models import EventAnalyzeRequest, EventAnalyzeResponse
from app.services.event_analyzer import analyze_event

router = APIRouter(tags=["Event Analyzer"])


@router.post("/analyze_event", response_model=EventAnalyzeResponse)
def analyze_event_route(payload: EventAnalyzeRequest) -> EventAnalyzeResponse:
    try:
        themes = analyze_event(payload.event)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # pragma: no cover - defensive catch-all
        raise HTTPException(status_code=502, detail=f"Theme extraction failed: {exc}") from exc
    return EventAnalyzeResponse(themes=themes)
