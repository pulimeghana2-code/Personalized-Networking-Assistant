"""Router: POST /log_feedback and GET /feedback"""
from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from app.database import get_session
from app.models import Feedback, FeedbackCreateRequest, FeedbackCreateResponse
from app.services.feedback_logger import list_feedback, log_feedback

router = APIRouter(tags=["Feedback Logger"])


@router.post("/log_feedback", response_model=FeedbackCreateResponse)
def log_feedback_route(
    payload: FeedbackCreateRequest, session: Session = Depends(get_session)
) -> FeedbackCreateResponse:
    try:
        record = log_feedback(
            session,
            prompt=payload.prompt,
            feedback=payload.feedback,
            conversation_id=payload.conversation_id,
            timestamp=payload.timestamp,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return FeedbackCreateResponse(success=True, id=record.id)


@router.get("/feedback", response_model=List[Feedback])
def get_feedback_route(session: Session = Depends(get_session)) -> List[Feedback]:
    return list_feedback(session)
